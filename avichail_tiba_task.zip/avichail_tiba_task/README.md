
# Tiba Task


## Installation

### Web
> open the terminal in the web folder and enter `npm i` it will install the packages first
> then `npm start` to run the client, default on localhost 3000
```shell
// inside web folder
$ npm i
$ npm start
```

---

### Server
> open the terminal in the server folder and enter `npm i` it will install the packages first
> then `npm start` to run the server, default on localhost 3001
```shell
// inside server folder
$ npm i
$ npm run dev
```

