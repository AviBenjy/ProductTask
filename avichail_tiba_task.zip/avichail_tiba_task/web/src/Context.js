import React from 'react'


export const ContextProducts = React.createContext({})
